package com.sobgog.habitmate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
