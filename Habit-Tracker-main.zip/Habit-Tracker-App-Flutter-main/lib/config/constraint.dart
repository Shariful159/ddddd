import 'package:flutter/material.dart';

EdgeInsetsGeometry defaultHorizontalViewPadding =
    const EdgeInsets.symmetric(horizontal: 15);
EdgeInsetsGeometry defaultTopPadding = const EdgeInsets.only(top: 30);
BorderRadius defaultBorderRadius = BorderRadius.circular(15);
// Martin Gogołowicz || SobGOG || 30.08.2023
// Last edit: Martin Gogołowicz || SobGOG || 30.08.2023